from flask import Flask, render_template, request, redirect, url_for
import platform
import os
import subprocess
import requests

app = Flask(__name__)

USERNAME = "trh4ckn0n"

# Fonction infos système
def get_system_info():
    return {
        "Hostname": platform.node(),
        "User": os.getenv("USER"),
        "OS": platform.platform(),
        "Kernel": platform.release(),
        "Arch": platform.machine(),
        "CPU": platform.processor(),
    }

# Fonction récupération des repos
def get_github_repos():
    res = requests.get(f"https://api.github.com/users/{USERNAME}/repos")
    if res.status_code == 200:
        return res.json()
    return []

@app.route("/")
def index():
    system_info = get_system_info()
    repos = get_github_repos()
    return render_template("index.html", system_info=system_info, repos=repos)

@app.route("/clone", methods=["POST"])
def clone_repo():
    url = request.form.get("repo_url")
    if url:
        os.system(f"git clone {url}")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
